
import XCTest
@testable import Assignment

class AcronymListViewControllerTests: XCTestCase {
    
    var sut: AcronymListViewController!
    var presenter: MockPresenter!

    override func setUpWithError() throws {
        try super.setUpWithError()
        presenter = MockPresenter()
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        sut = storyboard.instantiateViewController(identifier: "AcronymListViewController") as! AcronymListViewController
        sut.presenter = presenter
    }

    override func tearDownWithError() throws {
        try super.tearDownWithError()
        sut = nil
        presenter = nil
    }
    
    func testViewDidLoad() throws {
        sut.viewDidLoad()
        XCTAssertTrue(sut.tableView.dataSource === sut)
        sut.presenter?.fetchAcronyms(searchString: "Hello")
        XCTAssertTrue(sut.presenter != nil)
       
    }
}
