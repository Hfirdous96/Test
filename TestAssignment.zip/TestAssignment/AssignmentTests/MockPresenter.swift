import Foundation
@testable import Assignment



final class MockPresenter: Presenter {
    var interactor: Assignment.Interactor?
    
    var view: Assignment.AnyView?
    
    var router: Assignment.Router?
    
    func didFetchAcronyms(result: Result<[Assignment.Acronym], Assignment.APIError>) {
        methodsCalled.append("didFetchAcronyms")
    }
    
    
    private(set) var methodsCalled = [String]()
    
     func fetchAcronyms(searchString: String) {
        methodsCalled.append("fetchAcronyms")
    }
    
}
