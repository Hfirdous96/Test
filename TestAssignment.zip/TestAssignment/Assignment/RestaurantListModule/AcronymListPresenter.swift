import Foundation

class AcronymListPresenter: Presenter {
    
    var interactor: Interactor?
    
    func fetchAcronyms(searchString: String) {
        interactor?.fetchAcronyms(searchString: searchString)
    }
    
    
    var view: AnyView?
    var router: Router?

    func didFetchAcronyms(result: Result<[Acronym], APIError>) {
        switch result {
            case .success(let restaurants):
                view?.update(with: restaurants)
            case .failure(let error):
                view?.update(with: error)
        }
    }
}
