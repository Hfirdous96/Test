import Foundation
import UIKit

typealias EntryPoint = AnyView & UIViewController

protocol AnyView: AnyObject {
    var presenter: Presenter? { get set }
    func update(with restaurants: [Acronym])
    func update(with error: Error)
}

protocol Interactor {
    var presenter: Presenter? { get set }
    func fetchAcronyms(searchString: String)
}


protocol Presenter {
    var interactor: Interactor? { get set }
    var view: AnyView? { get set }
    var router: Router? { get set }
    
    func didFetchAcronyms(result: Result<[Acronym], APIError>)
    func fetchAcronyms(searchString: String)
}


protocol Router {
    var entryPoint: EntryPoint? { get set }
    static func start() -> Router
}
