import Foundation

class AcronymsListRouter: Router {
    var entryPoint: EntryPoint?
    
    static func start() -> Router {
        let viewController: AcronymListViewController = .instantiate()
        let view: AnyView = viewController
        var interactor: Interactor = AcronymsListInteractor()
        var presenter: Presenter = AcronymListPresenter()
        var router: Router = AcronymsListRouter()
        
        view.presenter = presenter
        interactor.presenter = presenter
        presenter.view = view
        presenter.interactor = interactor
        presenter.router = router
        
        router.entryPoint = view as? EntryPoint
        
        return router
        
        
    }
}
