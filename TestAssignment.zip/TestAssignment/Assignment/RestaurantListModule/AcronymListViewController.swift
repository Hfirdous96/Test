import UIKit

class AcronymListViewController: UIViewController, AnyView {
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet var tableView: UITableView!
    var presenter: Presenter?
    var lfs: [LF]?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        setupTableView()
    }
    
    private func setupUI() {
        view.backgroundColor = .white
        self.title = "Acronyms"
        navigationItem.backButtonTitle = " "
        navigationController?.navigationBar.backIndicatorImage = UIImage(systemName: "arrow.backward", withConfiguration: UIImage.SymbolConfiguration(pointSize: 16, weight: .bold))
        navigationController?.navigationBar.backIndicatorTransitionMaskImage = UIImage(systemName: "arrow.backward", withConfiguration: UIImage.SymbolConfiguration(pointSize: 16, weight: .bold))
        navigationController?.navigationBar.tintColor = .black
    }
    
    func setupTableView() {
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        tableView.delegate = self
        tableView.dataSource = self
        tableView.tableFooterView = UIView()
    }
    
    func update(with acronyms: [Acronym]) {
        DispatchQueue.main.async {
            self.lfs = acronyms.first?.lfs
            self.tableView.reloadData()
        }
    }
    
    func update(with error: Error) {
        //show Alert
    }
    
}

extension AcronymListViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        guard let lfsCount = lfs?.count else {
            return 0
        }
        return lfsCount
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "cell") else { return UITableViewCell() }
        cell.selectionStyle = .none
        cell.textLabel?.text = lfs?[indexPath.row].lf
        return cell
    }

}
// MARK: Acronym SearchBar delegates
extension AcronymListViewController: UISearchBarDelegate {
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder()
        if let searchText = searchBar.text, !searchText.isEmpty {
            presenter?.fetchAcronyms(searchString: searchText)
        }
    }
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        presenter?.fetchAcronyms(searchString: searchText)
    }
}
