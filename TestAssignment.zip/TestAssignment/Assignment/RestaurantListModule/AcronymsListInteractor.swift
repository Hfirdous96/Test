import Foundation

class AcronymsListInteractor: Interactor {
    var presenter: Presenter?
    
    func fetchAcronyms(searchString: String) {
        RestAPIClient().getData(searchString: searchString) {[weak self] result in
            switch result {
            case .success(let acronyms):
                self?.presenter?.didFetchAcronyms(result: .success(acronyms))
            case .failure(let error):
                self?.presenter?.didFetchAcronyms(result: .failure(.runtimeError(error.localizedDescription)))
            }
        }
    }
}


