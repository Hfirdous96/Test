import Foundation
import Alamofire

/// This class is an interface to call the rest API.

protocol RestAPIClientProtocol {
    func request<T: Codable>(type: T.Type,
                                            route: APIRouter,
                                            completion:@escaping (Result < T,
                                                                           APIError>)
                                                -> Void)
}

class RestAPIClient: RestAPIClientProtocol {
    
    /// Generic method to make the API request and decode the data to generic type.
     func request<T: Codable>(type: T.Type,
                                            route: APIRouter,
                                            completion:@escaping (Result < T,
                                                                           APIError>)
                                                -> Void) {
        
        AF.request(route).response { response in
            let result = response.result
            switch result {
            case .success(let data):
                guard let data = data else {
                    completion(.failure(.runtimeError("No Proper data recieved")))
                    return
                }
                
                guard let obj = try? JSONDecoder().decode(T.self, from: data) else {
                    completion(.failure(.runtimeError("No Proper data recieved")))
                    return
                }
                completion(.success(obj))
            case .failure(let error):
                completion(.failure(.runtimeError(error.localizedDescription)))
            }
        }
       
    }
    
    func getData(searchString: String,
                 completion:@escaping (Result<[Acronym], APIError>) -> Void) {
        return request(type: [Acronym].self, route: APIRouter.getData(str: searchString),
                       completion: completion)
        
    }
    
    
    
    
    
}
